/** Automatically generated file. DO NOT MODIFY */
package me.rayquincy.drafttwo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}